using System;
using Inventor;

namespace CustomCommand
{
    internal abstract class Command : IDisposable
    {
        protected Application _inventor;

        protected CustomCommand.Interaction _interaction;

        protected InteractionEvents _interactionEvents;
        protected SelectEvents _selectEvents;
        protected MouseEvents _mouseEvents;
        protected TriadEvents _triadEvents;
        protected bool _isExecuting;

        protected ButtonDefinition _buttonDefinition;
        public Inventor.ButtonDefinition ButtonDefinition
        {
            get { return _buttonDefinition; }
        }

        public void Dispose()
        {
            if (_buttonDefinition != null)
            {
                _buttonDefinition.OnExecute -= OnExecute;
                _buttonDefinition = null;
            }
        }

        public void CreateButton(Application application, string displayName, string internalName, CommandTypesEnum commandType, object clientId, string description, string toolTip, object standardIcon, object largeIcon, ButtonDisplayEnum buttonType, bool autoAddToGUI)
        {
            _inventor = application;

            _buttonDefinition = _inventor.CommandManager.ControlDefinitions.AddButtonDefinition(displayName, internalName, commandType, clientId, description, toolTip, standardIcon, largeIcon, buttonType);
            _buttonDefinition.OnExecute += OnExecute;
            _buttonDefinition.Enabled = false;

            if (autoAddToGUI)
                _buttonDefinition.AutoAddToGUI();
        }

        virtual protected void OnExecute(NameValueMap context)
        {
            if (_isExecuting)
                StopCommand();

            StartCommand();
        }

        virtual public void StartCommand()
        {
            StartInteraction();
            _buttonDefinition.Pressed = true;
            _isExecuting = true;
        }

        //must be implemented by the derived classes
        public abstract void ExecuteCommand();

        virtual public void StopCommand()
        {
            try
            {
                UnregisterEvents();
                StopInteraction();
                _buttonDefinition.Pressed = false;
                _isExecuting = false;
            }
            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.ToString());
            }
        }

        public void StartInteraction()
        {
            try
            {
                _interaction = new CustomCommand.Interaction();

                //set the parent to get the call back when event is terminated, or interaction is completed
                _interaction.SetParentCmd(this);

                //set the interaction events name to the button's internal name
                string strButtonDefObjInternalName = _buttonDefinition.InternalName;

                //start interaction events
                _interaction.StartInteraction(_inventor, strButtonDefObjInternalName, out _interactionEvents);
            }
            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.ToString());
            }
        }

        public void StopInteraction()
        {
            //terminate interaction events
            _interaction.StopInteraction();

            //m_interaction.Release();
            _interaction = null;

            _interactionEvents = null;
        }

        public void RegisterEvent(Interaction.InteractionTypeEnum interactionType)
        {
            //subscribe to the specified event type (selection, mouse etc.)
            object eventType = null;
            _interaction.RegisterEvent(interactionType, ref eventType);

            if (eventType != null)
            {
                if (eventType is SelectEvents)
                    _selectEvents = (SelectEvents)eventType;

                if (eventType is MouseEvents)
                    _mouseEvents = (MouseEvents)eventType;

                if (eventType is TriadEvents)
                    _triadEvents = (TriadEvents)eventType;
            }
        }

        public void UnregisterEvents()
        {
            _interaction.UnregisterEvents();

            _selectEvents = null;
            _mouseEvents = null;
            _triadEvents = null;
        }

        virtual public void EnableInteraction()
        {
            //enable interaction events
            _interaction.EnableInteraction();
        }

        virtual public void DisableInteraction()
        {
            //disable interaction events
            _interaction.DisableInteraction();
        }

        public void ExecuteChangeRequest(CustomCommand.ChangeRequest changeRequest, object changeDefinition, Inventor._Document document)
        {
            changeRequest.Execute(_inventor, changeDefinition, document);
        }

        virtual public void OnHelp(EventTimingEnum beforeOrAfter, NameValueMap context, out HandlingCodeEnum handlingCode)
        {
            handlingCode = HandlingCodeEnum.kEventNotHandled;
        }

        //-----------------------------------------------------------------------------
        //----- Implementation of Select Events sink methods
        //-----------------------------------------------------------------------------

        //-----------------------------------------------------------------------------
        virtual public void OnPreSelect(object preSelectEntity, out bool doHighlight, ObjectCollection morePreSelectEntities, SelectionDeviceEnum selectionDevice, Point modelPosition, Point2d viewPosition, View view)
        {
            doHighlight = false;
        }

        //-----------------------------------------------------------------------------
        public void OnPreSelectMouseMove(object preSelectEntity, Point modelPosition, Point2d viewPosition, View view)
        {
            // Not implemented
        }

        //-----------------------------------------------------------------------------
        public void OnStopPreSelect(Point modelPosition, Point2d viewPosition, View view)
        {
            // Not implemented
        }

        //-----------------------------------------------------------------------------
        virtual public void OnSelect(ObjectsEnumerator justSelectedEntities, SelectionDeviceEnum selectionDevice, Point modelPosition, Point2d viewPosition, View view)
        {
            // Not implemented
        }

        //-----------------------------------------------------------------------------
        public void OnUnSelect(ObjectsEnumerator unSelectedEntities, SelectionDeviceEnum selectionDevice, Point modelPosition, Point2d viewPosition, View view)
        {
            // Not implemented
        }

        //-----------------------------------------------------------------------------
        //----- Implementation of Mouse Events sink methods
        //-----------------------------------------------------------------------------

        //-----------------------------------------------------------------------------
        virtual public void OnMouseUp(MouseButtonEnum button, ShiftStateEnum shiftKeys, Point modelPosition, Point2d viewPosition, View view)
        {
            // Not implemented
        }

        //-----------------------------------------------------------------------------
        virtual public void OnMouseDown(MouseButtonEnum button, ShiftStateEnum shiftKeys, Point modelPosition, Point2d viewPosition, View view)
        {
            // Not implemented
        }

        //-----------------------------------------------------------------------------
        virtual public void OnMouseClick(MouseButtonEnum button, ShiftStateEnum shiftKeys, Point modelPosition, Point2d viewPosition, View view)
        {
            // Not implemented
        }

        //-----------------------------------------------------------------------------
        virtual public void OnMouseDoubleClick(MouseButtonEnum button, ShiftStateEnum shiftKeys, Point modelPosition, Point2d viewPosition, View view)
        {
            // Not implemented
        }

        //-----------------------------------------------------------------------------
        virtual public void OnMouseMove(MouseButtonEnum button, ShiftStateEnum shiftKeys, Point modelPosition, Point2d viewPosition, View view)
        {
            // Not implemented
        }

        //-----------------------------------------------------------------------------
        virtual public void OnMouseLeave(MouseButtonEnum button, ShiftStateEnum shiftKeys, View view)
        {
            // Not implemented
        }

        //-----------------------------------------------------------------------------
        //----- Implementation of Triad Events sink methods
        //-----------------------------------------------------------------------------

        //-----------------------------------------------------------------------------
        virtual public void OnActivate(NameValueMap context, out HandlingCodeEnum handlingCode)
        {
            // Not implemented
            handlingCode = HandlingCodeEnum.kEventNotHandled;
        }

        //-----------------------------------------------------------------------------
        virtual public void OnEndMove(TriadSegmentEnum selectedTriadSegment, ShiftStateEnum shiftKeys, Matrix coordinateSystem, NameValueMap context, out HandlingCodeEnum handlingCode)
        {
            // Not implemented
            handlingCode = HandlingCodeEnum.kEventNotHandled;
        }

        //----------------------------------------------------------------------------
        virtual public void OnMove(TriadSegmentEnum selectedTriadSegment, ShiftStateEnum shiftKeys, Matrix coordinateSystem, NameValueMap context, out HandlingCodeEnum handlingCode)
        {
            // Not implemented
            handlingCode = HandlingCodeEnum.kEventNotHandled;
        }

        //-----------------------------------------------------------------------------
        virtual public void OnEndSequence(bool cancelled, Matrix coordinateSystem, NameValueMap context, out HandlingCodeEnum handlingCode)
        {
            // Not implemented
            handlingCode = HandlingCodeEnum.kEventNotHandled;
        }

        //-----------------------------------------------------------------------------
        virtual public void OnStartSequence(Matrix coordinateSystem, NameValueMap context, out HandlingCodeEnum handlingCode)
        {
            // Not implemented
            handlingCode = HandlingCodeEnum.kEventNotHandled;
        }

        //-----------------------------------------------------------------------------
        virtual public void OnMoveTriadOnlyToggle(bool moveTriadOnly, EventTimingEnum beforeOrAfter, NameValueMap context, out HandlingCodeEnum handlingCode)
        {
            // Not implemented
            handlingCode = HandlingCodeEnum.kEventNotHandled;
        }

        //-----------------------------------------------------------------------------
        virtual public void OnStartMove(TriadSegmentEnum selectedTriadSegment, ShiftStateEnum shiftKeys, Matrix coordinateSystem, NameValueMap context, out HandlingCodeEnum handlingCode)
        {
            // Not implemented
            handlingCode = HandlingCodeEnum.kEventNotHandled;
        }

        //-----------------------------------------------------------------------------
        virtual public void OnTerminate(bool cancelled, NameValueMap context, out HandlingCodeEnum handlingCode)
        {
            // Not implemented
            handlingCode = HandlingCodeEnum.kEventNotHandled;
        }

        //-----------------------------------------------------------------------------
        virtual public void OnSegmentSelectionChange(TriadSegmentEnum selectedTriadSegment, EventTimingEnum beforeOrAfter, NameValueMap context, out HandlingCodeEnum handlingCode)
        {
            // Not implemented
            handlingCode = HandlingCodeEnum.kEventNotHandled;
        }
    }
}
