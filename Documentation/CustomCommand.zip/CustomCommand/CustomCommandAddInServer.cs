using System;
using System.Runtime.InteropServices;
using Inventor;

namespace CustomCommand
{
    /// <summary>
    /// This is the primary AddIn Server class that implements the ApplicationAddInServer interface
    /// that all Inventor AddIns are required to implement. The communication between Inventor and
    /// the AddIn is via the methods on this interface.
    /// </summary>
    [GuidAttribute("140918FF-668A-435a-BD5E-57EF81CA5C5D")]
    public class CustomCommandAddInServer : ApplicationAddInServer
    {
        private Inventor.Application _inventor;

        private RackFaceCmd _rackFaceCommand;
        private string m_addInCLSIDString;
        private UserInterfaceEvents _userInterfaceEvents;

        public CustomCommandAddInServer()
        {
            _inventor = null;
            _rackFaceCommand = null;
        }

        #region ApplicationAddInServer Members

        public void Activate(ApplicationAddInSite addInSiteObject, bool firstTime)
        {
            try
            {
                _inventor = addInSiteObject.Application;

                // register events
                _userInterfaceEvents = _inventor.UserInterfaceManager.UserInterfaceEvents;
                _userInterfaceEvents.OnResetCommandBars += OnResetCommandBars;
                _userInterfaceEvents.OnEnvironmentChange += OnEnvironmentChange;
                _userInterfaceEvents.OnResetRibbonInterface += OnResetRibbonInterface;

                // retrieve the GUID for this class
                GuidAttribute addInCLSID;
                addInCLSID = (GuidAttribute)GuidAttribute.GetCustomAttribute(typeof(CustomCommandAddInServer), typeof(GuidAttribute));
                m_addInCLSIDString = "{" + addInCLSID.Value + "}";

                //create the command button(s)
                //create instance of the "Rack Face" command class 
                _rackFaceCommand = new RackFaceCmd();
                _rackFaceCommand.CreateButton(_inventor, "Rack Face", "Autodesk:CustomCommand:RackFaceCmd", CommandTypesEnum.kShapeEditCmdType, m_addInCLSIDString, "Creates a rack feature", "Creates a rack feature", "", "", ButtonDisplayEnum.kDisplayTextInLearningMode, false);

                // Create the change definitions collection for this AddIn
                var changeDefinitions = _inventor.ChangeManager.Add(m_addInCLSIDString);
                changeDefinitions.Add("Autodesk:CustomCommand:RackFaceChgDef", "Rack Face");

                // create the command category
                var rackFaceCommandCategory = _inventor.CommandManager.CommandCategories.Add("Rack Face", "Autodesk:CustomCommand:RackFaceCmdCat", m_addInCLSIDString);
                rackFaceCommandCategory.Add(_rackFaceCommand.ButtonDefinition);

                if (firstTime == true)
                {
                    UserInterfaceManager userInterfaceManager = _inventor.UserInterfaceManager;

                    if (userInterfaceManager.InterfaceStyle == InterfaceStyleEnum.kClassicInterface)
                        //add the "Rack Face" button to the toolbar
                        userInterfaceManager.CommandBars["PMxPartFeatureCmdBar"].Controls.AddButton(_rackFaceCommand.ButtonDefinition, 0);
                    else
                        userInterfaceManager.Ribbons["Part"].RibbonTabs["id_TabModel"].RibbonPanels["id_PanelP_ModelModify"].CommandControls.AddButton(
                            ButtonDefinition: _rackFaceCommand.ButtonDefinition,
                            UseLargeIcon: false,
                            ShowText: true,
                            TargetControlInternalName: "",
                            InsertBeforeTargetControl: false
                        );
                }
            }
            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.ToString());
            }
        }

        public void Deactivate()
        {
            // Unregister events
            _userInterfaceEvents.OnResetCommandBars -= OnResetCommandBars;
            _userInterfaceEvents.OnEnvironmentChange -= OnEnvironmentChange;
            _userInterfaceEvents.OnResetRibbonInterface -= OnResetRibbonInterface;
            _userInterfaceEvents = null;

            //remove the command button(s)
            _rackFaceCommand.Dispose();
            _rackFaceCommand = null;

            //delete change definition(s)
            var changeDefinitions = _inventor.ChangeManager[m_addInCLSIDString];
            changeDefinitions["Autodesk:CustomCommand:RackFaceChgDef"].Delete();

            Marshal.ReleaseComObject(_inventor);
            _inventor = null;

            GC.WaitForPendingFinalizers();
            GC.Collect();
        }

        public void ExecuteCommand(int commandID)
        {
            //this method was used to notify when an AddIn command was executed
            //the CommandID parameter identifies the command that was executed

            //Note:this method is now obsolete, you should use the new
            //ControlDefinition objects to implement commands, they have
            //their own event sinks to notify when the command is executed
        }

        public object Automation
        {
            //if you want to return an interface to another client of this addin,
            //implement that interface in a class and return that class object 
            //through this property

            get
            {
                // TODO:  Add ApplicationAddInServer.Automation getter implementation
                return null;
            }
        }

        #endregion

        private void OnResetCommandBars(ObjectsEnumerator commandBars, NameValueMap context)
        {
            try
            {
                CommandBar commandBar;
                for (int commandBarCt = 1; commandBarCt <= commandBars.Count; commandBarCt++)
                {
                    commandBar = (Inventor.CommandBar)commandBars[commandBarCt];
                    if (commandBar.InternalName == "PMxPartFeatureCmdBar")
                    {
                        //add "Rack Face" button back to the part features toolbar
                        commandBar.Controls.AddButton(_rackFaceCommand.ButtonDefinition, 0);

                        return;
                    }
                }
            }
            catch (Exception e)
            {
                System.Windows.Forms.MessageBox.Show(e.ToString());
            }
        }

        private void OnEnvironmentChange(Inventor.Environment environment, EnvironmentStateEnum environmentState, EventTimingEnum beforeOrAfter, NameValueMap context, out HandlingCodeEnum handlingCode)
        {
            try
            {
                String envInternalName;
                envInternalName = environment.InternalName;

                if (envInternalName == "PMxPartEnvironment")
                {
                    //enable the "Rack Face" button when the part environment is activated or resumed
                    if (environmentState == EnvironmentStateEnum.kActivateEnvironmentState || environmentState == EnvironmentStateEnum.kResumeEnvironmentState)
                        _rackFaceCommand.ButtonDefinition.Enabled = true;


                    //disable the "Rack Face" button when the part environment is terminated or suspended
                    if (environmentState == EnvironmentStateEnum.kTerminateEnvironmentState || environmentState == EnvironmentStateEnum.kSuspendEnvironmentState)
                        _rackFaceCommand.ButtonDefinition.Enabled = false;
                }

            }
            catch (Exception e)
            {
                System.Windows.Forms.MessageBox.Show(e.ToString());
            }
            handlingCode = HandlingCodeEnum.kEventNotHandled;
        }

        private void OnResetRibbonInterface(NameValueMap context)
        {
            try
            {
                // Add the button to the Modify panel on Model tab in Part Ribbon
                UserInterfaceManager userInterfaceMgr = _inventor.UserInterfaceManager;

                // Get Part Ribbon
                Ribbons ribbons = userInterfaceMgr.Ribbons;
                Ribbon partRibbon = ribbons["Part"];

                // Get Modify Panel
                RibbonTab modelRibbonTab = partRibbon.RibbonTabs["id_TabModel"];
                RibbonPanel modifyRibbonPanel = modelRibbonTab.RibbonPanels["id_PanelP_ModelModify"];

                // Add the "Rack Face" button to the Panel
                modifyRibbonPanel.CommandControls.AddButton(_rackFaceCommand.ButtonDefinition,
                                                            false,
                                                            true,
                                                            "",
                                                            false);
            }
            catch (Exception e)
            {
                System.Windows.Forms.MessageBox.Show(e.ToString());
            }
        }
    }
}
