using System;
using Inventor;
using System.Linq;

namespace CustomCommand
{
    internal class Interaction
    {
        internal enum InteractionTypeEnum
        {
            kSelection,
            kMouse,
            kKeyboard,
            kTriad
        };

        // Interaction Types collection
        private System.Collections.ArrayList _interactionTypes;

        //InteractionEvents object
        private InteractionEvents _interactionEvents;

        //SelectEvents object
        private SelectEvents _selectEvents;

        //MouseEvents object
        private MouseEvents _mouseEvents;

        //TriadEvents object
        private TriadEvents _triadEvents;

        //Parent Command object
        private CustomCommand.Command m_parentCmd;

        //Interaction Event Delegates
        private InteractionEventsSink_OnTerminateEventHandler m_interaction_OnTerminate_Delegate;
        private InteractionEventsSink_OnHelpEventHandler m_interaction_OnHelp_Delegate;

        //Select Event Delegates
        private SelectEventsSink_OnPreSelectEventHandler m_select_OnPreSelect_Delegate;
        private SelectEventsSink_OnPreSelectMouseMoveEventHandler m_Select_OnPreSelectMouseMove_Delegate;
        private SelectEventsSink_OnStopPreSelectEventHandler m_Select_OnStopPreSelect_Delegate;
        private SelectEventsSink_OnSelectEventHandler m_Select_OnSelect_Delegate;
        private SelectEventsSink_OnUnSelectEventHandler m_Select_OnUnSelect_Delegate;

        //Mouse Event Delegates
        private MouseEventsSink_OnMouseUpEventHandler m_Mouse_OnMouseUp_Delegate;
        private MouseEventsSink_OnMouseDownEventHandler m_Mouse_OnMouseDown_Delegate;
        private MouseEventsSink_OnMouseClickEventHandler m_Mouse_OnMouseClick_Delegate;
        private MouseEventsSink_OnMouseDoubleClickEventHandler m_Mouse_OnMouseDoubleClick_Delegate;
        private MouseEventsSink_OnMouseMoveEventHandler m_Mouse_OnMouseMove_Delegate;
        private MouseEventsSink_OnMouseLeaveEventHandler m_Mouse_OnMouseLeave_Delegate;

        //Triad Event Delegates
        private TriadEventsSink_OnActivateEventHandler m_Triad_OnActivate_Delegate;
        private TriadEventsSink_OnEndMoveEventHandler m_Triad_OnEndMove_Delegate;
        private TriadEventsSink_OnEndSequenceEventHandler m_Triad_OnEndSequence_Delegate;
        private TriadEventsSink_OnMoveEventHandler m_Triad_OnMove_Delegate;
        private TriadEventsSink_OnMoveTriadOnlyToggleEventHandler m_Triad_OnMoveTriadOnlyToggle_Delegate;
        private TriadEventsSink_OnSegmentSelectionChangeEventHandler m_Triad_OnSegmentSelectionChange_Delegate;
        private TriadEventsSink_OnStartMoveEventHandler m_Triad_OnStartMove_Delegate;
        private TriadEventsSink_OnStartSequenceEventHandler m_Triad_OnStartSequence_Delegate;
        private TriadEventsSink_OnTerminateEventHandler m_Triad_OnTerminate_Delegate;

        public Interaction()
        {
            _interactionTypes = new System.Collections.ArrayList();

            _interactionEvents = null;
            _selectEvents = null;
            _mouseEvents = null;
            _triadEvents = null;

            m_parentCmd = null;
        }

        public void StartInteraction(Application application, string interactionName, out InteractionEvents interactionEvents)
        {
            try
            {
                //create the InteractionEvents object
                _interactionEvents = application.CommandManager.CreateInteractionEvents();

                //define that we want select events rather than mouse events
                _interactionEvents.SelectionActive = true;

                //set the name for the interaction events
                _interactionEvents.Name = interactionName;

                //connect the interaction event sink
                m_interaction_OnTerminate_Delegate = new InteractionEventsSink_OnTerminateEventHandler(InteractionEvents_OnTerminate);
                _interactionEvents.OnTerminate += m_interaction_OnTerminate_Delegate;

                m_interaction_OnHelp_Delegate = new InteractionEventsSink_OnHelpEventHandler(InteractionEvents_OnHelp);
                _interactionEvents.OnHelp += m_interaction_OnHelp_Delegate;

                //set a reference to the select events
                _selectEvents = _interactionEvents.SelectEvents;

                //connect the select event sink
                m_select_OnPreSelect_Delegate = new SelectEventsSink_OnPreSelectEventHandler(SelectEvents_OnPreSelect);
                _selectEvents.OnPreSelect += m_select_OnPreSelect_Delegate;

                m_Select_OnPreSelectMouseMove_Delegate = new SelectEventsSink_OnPreSelectMouseMoveEventHandler(SelectEvents_OnPreSelectMouseMove);
                _selectEvents.OnPreSelectMouseMove += m_Select_OnPreSelectMouseMove_Delegate;

                m_Select_OnStopPreSelect_Delegate = new SelectEventsSink_OnStopPreSelectEventHandler(SelectEvents_OnStopPreSelect);
                _selectEvents.OnStopPreSelect += m_Select_OnStopPreSelect_Delegate;

                m_Select_OnSelect_Delegate = new SelectEventsSink_OnSelectEventHandler(SelectEvents_OnSelect);
                _selectEvents.OnSelect += m_Select_OnSelect_Delegate;

                m_Select_OnUnSelect_Delegate = new SelectEventsSink_OnUnSelectEventHandler(SelectEvents_OnUnSelect);
                _selectEvents.OnUnSelect += m_Select_OnUnSelect_Delegate;

                //set a reference to the mouse events
                _mouseEvents = _interactionEvents.MouseEvents;

                //connect the mouse event sink
                m_Mouse_OnMouseUp_Delegate = new MouseEventsSink_OnMouseUpEventHandler(MouseEvents_OnMouseUp);
                _mouseEvents.OnMouseUp += m_Mouse_OnMouseUp_Delegate;

                m_Mouse_OnMouseDown_Delegate = new MouseEventsSink_OnMouseDownEventHandler(MouseEvents_OnMouseDown);
                _mouseEvents.OnMouseDown += m_Mouse_OnMouseDown_Delegate;

                m_Mouse_OnMouseClick_Delegate = new MouseEventsSink_OnMouseClickEventHandler(MouseEvents_OnMouseClick);
                _mouseEvents.OnMouseClick += m_Mouse_OnMouseClick_Delegate;

                m_Mouse_OnMouseDoubleClick_Delegate = new MouseEventsSink_OnMouseDoubleClickEventHandler(MouseEvents_OnMouseDoubleClick);
                _mouseEvents.OnMouseDoubleClick += m_Mouse_OnMouseDoubleClick_Delegate;

                m_Mouse_OnMouseMove_Delegate = new MouseEventsSink_OnMouseMoveEventHandler(MouseEvents_OnMouseMove);
                _mouseEvents.OnMouseMove += m_Mouse_OnMouseMove_Delegate;

                m_Mouse_OnMouseLeave_Delegate = new MouseEventsSink_OnMouseLeaveEventHandler(MouseEvents_OnMouseLeave);
                _mouseEvents.OnMouseLeave += m_Mouse_OnMouseLeave_Delegate;

                //set a reference to the triad events
                _triadEvents = _interactionEvents.TriadEvents;

                //connect the triad event sink
                m_Triad_OnActivate_Delegate = new TriadEventsSink_OnActivateEventHandler(TriadEvents_OnActivate);
                _triadEvents.OnActivate += m_Triad_OnActivate_Delegate;

                m_Triad_OnEndMove_Delegate = new TriadEventsSink_OnEndMoveEventHandler(TriadEvents_OnEndMove);
                _triadEvents.OnEndMove += m_Triad_OnEndMove_Delegate;

                m_Triad_OnEndSequence_Delegate = new TriadEventsSink_OnEndSequenceEventHandler(TriadEvents_OnEndSequence);
                _triadEvents.OnEndSequence += m_Triad_OnEndSequence_Delegate;

                m_Triad_OnMove_Delegate = new TriadEventsSink_OnMoveEventHandler(TriadEvents_OnMove);
                _triadEvents.OnMove += m_Triad_OnMove_Delegate;

                m_Triad_OnMoveTriadOnlyToggle_Delegate = new TriadEventsSink_OnMoveTriadOnlyToggleEventHandler(TriadEvents_OnMoveTriadOnlyToggle);
                _triadEvents.OnMoveTriadOnlyToggle += m_Triad_OnMoveTriadOnlyToggle_Delegate;

                m_Triad_OnSegmentSelectionChange_Delegate = new TriadEventsSink_OnSegmentSelectionChangeEventHandler(TriadEvents_OnSegmentSelectionChange);
                _triadEvents.OnSegmentSelectionChange += m_Triad_OnSegmentSelectionChange_Delegate;

                m_Triad_OnStartMove_Delegate = new TriadEventsSink_OnStartMoveEventHandler(TriadEvents_OnStartMove);
                _triadEvents.OnStartMove += m_Triad_OnStartMove_Delegate;

                m_Triad_OnStartSequence_Delegate = new TriadEventsSink_OnStartSequenceEventHandler(TriadEvents_OnStartSequence);
                _triadEvents.OnStartSequence += m_Triad_OnStartSequence_Delegate;

                m_Triad_OnTerminate_Delegate = new TriadEventsSink_OnTerminateEventHandler(TriadEvents_OnTerminate);
                _triadEvents.OnTerminate += m_Triad_OnTerminate_Delegate;

                //start the InteractionEvents 
                _interactionEvents.Start();
            }
            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.ToString());
            }
            finally
            {
                interactionEvents = _interactionEvents;
            }
        }

        public void StopInteraction()
        {
            if (_interactionEvents == null)
                return;

            _interactionEvents.OnTerminate -= m_interaction_OnTerminate_Delegate;
            _interactionEvents.OnHelp -= m_interaction_OnHelp_Delegate;

            _interactionEvents.Stop();
            _interactionEvents = null;
        }

        public void RegisterEvent(InteractionTypeEnum interactionType, ref object eventType)
        {
            foreach (InteractionTypeEnum value in _interactionTypes)
                if (value == interactionType)
                    return;

            // This interaction type isn't registered yet, so let's subscribe to the event.
            _interactionTypes.Add(interactionType);

            switch (interactionType)
            {
                case InteractionTypeEnum.kSelection:
                    _selectEvents = _interactionEvents.SelectEvents;
                    _selectEvents.OnPreSelect += m_select_OnPreSelect_Delegate;
                    _selectEvents.OnPreSelectMouseMove += m_Select_OnPreSelectMouseMove_Delegate;
                    _selectEvents.OnStopPreSelect += m_Select_OnStopPreSelect_Delegate;
                    _selectEvents.OnSelect += m_Select_OnSelect_Delegate;
                    _selectEvents.OnUnSelect += m_Select_OnUnSelect_Delegate;

                    //specify burn through
                    _selectEvents.PreSelectBurnThrough = true;

                    eventType = _selectEvents;
                    break;

                case InteractionTypeEnum.kMouse:
                    _mouseEvents = _interactionEvents.MouseEvents;
                    _mouseEvents.OnMouseUp += m_Mouse_OnMouseUp_Delegate;
                    _mouseEvents.OnMouseDown += m_Mouse_OnMouseDown_Delegate;
                    _mouseEvents.OnMouseClick += m_Mouse_OnMouseClick_Delegate;
                    _mouseEvents.OnMouseDoubleClick += m_Mouse_OnMouseDoubleClick_Delegate;
                    _mouseEvents.OnMouseMove += m_Mouse_OnMouseMove_Delegate;
                    _mouseEvents.OnMouseLeave += m_Mouse_OnMouseLeave_Delegate;
                    eventType = _mouseEvents;
                    break;

                case InteractionTypeEnum.kTriad:
                    _triadEvents = _interactionEvents.TriadEvents;
                    _triadEvents.OnActivate += m_Triad_OnActivate_Delegate;
                    _triadEvents.OnEndMove += m_Triad_OnEndMove_Delegate;
                    _triadEvents.OnEndSequence += m_Triad_OnEndSequence_Delegate;
                    _triadEvents.OnMove += m_Triad_OnMove_Delegate;
                    _triadEvents.OnMoveTriadOnlyToggle += m_Triad_OnMoveTriadOnlyToggle_Delegate;
                    _triadEvents.OnSegmentSelectionChange += m_Triad_OnSegmentSelectionChange_Delegate;
                    _triadEvents.OnStartMove += m_Triad_OnStartMove_Delegate;
                    _triadEvents.OnStartSequence += m_Triad_OnStartSequence_Delegate;
                    _triadEvents.OnTerminate += m_Triad_OnTerminate_Delegate;
                    eventType = _triadEvents;
                    break;
            }
        }

        public void UnregisterEvents()
        {
            int interactionEvtsCount;

            for (interactionEvtsCount = 0; interactionEvtsCount < _interactionTypes.Count; interactionEvtsCount++)
                switch ((InteractionTypeEnum)_interactionTypes[interactionEvtsCount])
                {
                    case InteractionTypeEnum.kSelection:
                        if (_selectEvents != null)
                        {
                            _selectEvents.OnPreSelect -= m_select_OnPreSelect_Delegate;
                            _selectEvents.OnPreSelectMouseMove -= m_Select_OnPreSelectMouseMove_Delegate;
                            _selectEvents.OnStopPreSelect -= m_Select_OnStopPreSelect_Delegate;
                            _selectEvents.OnSelect -= m_Select_OnSelect_Delegate;
                            _selectEvents.OnUnSelect -= m_Select_OnUnSelect_Delegate;

                            _selectEvents = null;
                        }
                        break;

                    case InteractionTypeEnum.kMouse:
                        if (_mouseEvents != null)
                        {
                            _mouseEvents.OnMouseUp -= m_Mouse_OnMouseUp_Delegate;
                            _mouseEvents.OnMouseDown -= m_Mouse_OnMouseDown_Delegate;
                            _mouseEvents.OnMouseClick -= m_Mouse_OnMouseClick_Delegate;
                            _mouseEvents.OnMouseDoubleClick -= m_Mouse_OnMouseDoubleClick_Delegate;
                            _mouseEvents.OnMouseMove -= m_Mouse_OnMouseMove_Delegate;
                            _mouseEvents.OnMouseLeave -= m_Mouse_OnMouseLeave_Delegate;

                            _mouseEvents = null;
                        }
                        break;

                    case InteractionTypeEnum.kTriad:
                        if (_triadEvents != null)
                        {
                            _triadEvents.OnActivate -= m_Triad_OnActivate_Delegate;
                            _triadEvents.OnEndMove -= m_Triad_OnEndMove_Delegate;
                            _triadEvents.OnEndSequence -= m_Triad_OnEndSequence_Delegate;
                            _triadEvents.OnMove -= m_Triad_OnMove_Delegate;
                            _triadEvents.OnMoveTriadOnlyToggle -= m_Triad_OnMoveTriadOnlyToggle_Delegate;
                            _triadEvents.OnSegmentSelectionChange -= m_Triad_OnSegmentSelectionChange_Delegate;
                            _triadEvents.OnStartMove -= m_Triad_OnStartMove_Delegate;
                            _triadEvents.OnStartSequence -= m_Triad_OnStartSequence_Delegate;
                            _triadEvents.OnTerminate -= m_Triad_OnTerminate_Delegate;

                            _triadEvents = null;
                        }
                        break;
                }

            _interactionTypes.Clear();
        }

        public void EnableInteraction()
        {
            //enable events
            int interactionEvtsCount;
            for (interactionEvtsCount = 0; interactionEvtsCount < _interactionTypes.Count; interactionEvtsCount++)
            {
                switch ((InteractionTypeEnum)_interactionTypes[interactionEvtsCount])
                {
                    case InteractionTypeEnum.kSelection:

                        //re-subscribe to selection events 
                        if (_selectEvents == null)
                        {
                            //set a reference to the select events
                            _selectEvents = _interactionEvents.SelectEvents;

                            //connect the select event sink
                            _selectEvents.OnPreSelect += m_select_OnPreSelect_Delegate;
                            _selectEvents.OnPreSelectMouseMove += m_Select_OnPreSelectMouseMove_Delegate;
                            _selectEvents.OnStopPreSelect += m_Select_OnStopPreSelect_Delegate;
                            _selectEvents.OnSelect += m_Select_OnSelect_Delegate;
                            _selectEvents.OnUnSelect += m_Select_OnUnSelect_Delegate;

                            //specify burn through
                            _selectEvents.PreSelectBurnThrough = true;
                        }

                        break;

                    case InteractionTypeEnum.kMouse:

                        //re-subscribe to mouse events 
                        if (_mouseEvents == null)
                        {
                            //set a reference to the mouse events
                            _mouseEvents = _interactionEvents.MouseEvents;

                            //connect the mouse event sink
                            _mouseEvents.OnMouseUp += m_Mouse_OnMouseUp_Delegate;
                            _mouseEvents.OnMouseDown += m_Mouse_OnMouseDown_Delegate;
                            _mouseEvents.OnMouseClick += m_Mouse_OnMouseClick_Delegate;
                            _mouseEvents.OnMouseDoubleClick += m_Mouse_OnMouseDoubleClick_Delegate;
                            _mouseEvents.OnMouseMove += m_Mouse_OnMouseMove_Delegate;
                            _mouseEvents.OnMouseLeave += m_Mouse_OnMouseLeave_Delegate;
                        }

                        break;

                    case InteractionTypeEnum.kTriad:

                        //re-subscribe to triad events 
                        if (_triadEvents == null)
                        {
                            //set a reference to the triad events
                            _triadEvents = _interactionEvents.TriadEvents;

                            //connect the triad event sink
                            _triadEvents.OnActivate += m_Triad_OnActivate_Delegate;
                            _triadEvents.OnEndMove += m_Triad_OnEndMove_Delegate;
                            _triadEvents.OnEndSequence += m_Triad_OnEndSequence_Delegate;
                            _triadEvents.OnMove += m_Triad_OnMove_Delegate;
                            _triadEvents.OnMoveTriadOnlyToggle += m_Triad_OnMoveTriadOnlyToggle_Delegate;
                            _triadEvents.OnSegmentSelectionChange += m_Triad_OnSegmentSelectionChange_Delegate;
                            _triadEvents.OnStartMove += m_Triad_OnStartMove_Delegate;
                            _triadEvents.OnStartSequence += m_Triad_OnStartSequence_Delegate;
                            _triadEvents.OnTerminate += m_Triad_OnTerminate_Delegate;
                        }

                        break;
                }
            }
        }

        public void DisableInteraction()
        {
            //disable subscribed to events
            int interactionEvtsCount;
            for (interactionEvtsCount = 0; interactionEvtsCount < _interactionTypes.Count; interactionEvtsCount++)
            {
                switch ((InteractionTypeEnum)_interactionTypes[interactionEvtsCount])
                {
                    case InteractionTypeEnum.kSelection:

                        //un-subscribe and delete selection events
                        if (_selectEvents != null)
                        {
                            _selectEvents.OnPreSelect -= m_select_OnPreSelect_Delegate;
                            _selectEvents.OnPreSelectMouseMove -= m_Select_OnPreSelectMouseMove_Delegate;
                            _selectEvents.OnStopPreSelect -= m_Select_OnStopPreSelect_Delegate;
                            _selectEvents.OnSelect -= m_Select_OnSelect_Delegate;
                            _selectEvents.OnUnSelect -= m_Select_OnUnSelect_Delegate;

                            _selectEvents = null;
                        }

                        break;

                    case InteractionTypeEnum.kMouse:

                        //un-subscribe and delete mouse events 
                        if (_mouseEvents != null)
                        {
                            _mouseEvents.OnMouseUp -= m_Mouse_OnMouseUp_Delegate;
                            _mouseEvents.OnMouseDown -= m_Mouse_OnMouseDown_Delegate;
                            _mouseEvents.OnMouseClick -= m_Mouse_OnMouseClick_Delegate;
                            _mouseEvents.OnMouseDoubleClick -= m_Mouse_OnMouseDoubleClick_Delegate;
                            _mouseEvents.OnMouseMove -= m_Mouse_OnMouseMove_Delegate;
                            _mouseEvents.OnMouseLeave -= m_Mouse_OnMouseLeave_Delegate;

                            _mouseEvents = null;
                        }

                        break;

                    case InteractionTypeEnum.kTriad:

                        //un-subscribe and delete triad events
                        if (_triadEvents != null)
                        {
                            _triadEvents.OnActivate -= m_Triad_OnActivate_Delegate;
                            _triadEvents.OnEndMove -= m_Triad_OnEndMove_Delegate;
                            _triadEvents.OnEndSequence -= m_Triad_OnEndSequence_Delegate;
                            _triadEvents.OnMove -= m_Triad_OnMove_Delegate;
                            _triadEvents.OnMoveTriadOnlyToggle -= m_Triad_OnMoveTriadOnlyToggle_Delegate;
                            _triadEvents.OnSegmentSelectionChange -= m_Triad_OnSegmentSelectionChange_Delegate;
                            _triadEvents.OnStartMove -= m_Triad_OnStartMove_Delegate;
                            _triadEvents.OnStartSequence -= m_Triad_OnStartSequence_Delegate;
                            _triadEvents.OnTerminate -= m_Triad_OnTerminate_Delegate;

                            _triadEvents = null;
                        }

                        break;
                }
            }
        }

        public void SetParentCmd(CustomCommand.Command parentCmd)
        {
            //store a copy of the parent command
            m_parentCmd = parentCmd;
        }

        //-----------------------------------------------------------------------------
        //----- Implementation of Interaction Events sink methods
        //-----------------------------------------------------------------------------

        //-----------------------------------------------------------------------------		

        public void InteractionEvents_OnTerminate()
        {
            //terminate the command
            m_parentCmd.StopCommand();
        }

        //-----------------------------------------------------------------------------
        public void InteractionEvents_OnHelp(EventTimingEnum beforeOrAfter, NameValueMap context, out HandlingCodeEnum handlingCode)
        {
            m_parentCmd.OnHelp(beforeOrAfter, context, out handlingCode);
        }

        //-----------------------------------------------------------------------------
        //----- Implementation of Select Events sink methods
        //-----------------------------------------------------------------------------

        //-----------------------------------------------------------------------------
        public void SelectEvents_OnPreSelect(ref object preSelectEntity, out bool doHighlight, ref ObjectCollection morePreSelectEntities, SelectionDeviceEnum selectionDevice, Point modelPosition, Point2d viewPosition, View view)
        {
            m_parentCmd.OnPreSelect(preSelectEntity, out doHighlight, morePreSelectEntities, selectionDevice, modelPosition, viewPosition, view);
        }

        //-----------------------------------------------------------------------------
        public void SelectEvents_OnPreSelectMouseMove(object preSelectEntity, Point modelPosition, Point2d viewPosition, View view)
        {
            m_parentCmd.OnPreSelectMouseMove(preSelectEntity, modelPosition, viewPosition, view);
        }

        //-----------------------------------------------------------------------------
        public void SelectEvents_OnStopPreSelect(Point modelPosition, Point2d viewPosition, View view)
        {
            m_parentCmd.OnStopPreSelect(modelPosition, viewPosition, view);
        }

        //-----------------------------------------------------------------------------
        public void SelectEvents_OnSelect(ObjectsEnumerator justSelectedEntities, SelectionDeviceEnum selectionDevice, Point modelPosition, Point2d viewPosition, View view)
        {
            m_parentCmd.OnSelect(justSelectedEntities, selectionDevice, modelPosition, viewPosition, view);
        }

        //-----------------------------------------------------------------------------
        public void SelectEvents_OnUnSelect(ObjectsEnumerator unSelectedEntities, SelectionDeviceEnum selectionDevice, Point modelPosition, Point2d viewPosition, View view)
        {
            m_parentCmd.OnUnSelect(unSelectedEntities, selectionDevice, modelPosition, viewPosition, view);
        }

        //-----------------------------------------------------------------------------
        //----- Implementation of Mouse Events sink methods
        //-----------------------------------------------------------------------------

        //-----------------------------------------------------------------------------
        public void MouseEvents_OnMouseUp(MouseButtonEnum button, ShiftStateEnum shiftKeys, Point modelPosition, Point2d viewPosition, View view)
        {
            m_parentCmd.OnMouseUp(button, shiftKeys, modelPosition, viewPosition, view);
        }

        //-----------------------------------------------------------------------------
        public void MouseEvents_OnMouseDown(MouseButtonEnum button, ShiftStateEnum shiftKeys, Point modelPosition, Point2d viewPosition, View view)
        {
            m_parentCmd.OnMouseDown(button, shiftKeys, modelPosition, viewPosition, view);
        }

        //-----------------------------------------------------------------------------
        public void MouseEvents_OnMouseClick(MouseButtonEnum button, ShiftStateEnum shiftKeys, Point modelPosition, Point2d viewPosition, View view)
        {
            m_parentCmd.OnMouseClick(button, shiftKeys, modelPosition, viewPosition, view);
        }

        //-----------------------------------------------------------------------------
        public void MouseEvents_OnMouseDoubleClick(MouseButtonEnum button, ShiftStateEnum shiftKeys, Point modelPosition, Point2d viewPosition, View view)
        {
            m_parentCmd.OnMouseDoubleClick(button, shiftKeys, modelPosition, viewPosition, view);
        }

        //-----------------------------------------------------------------------------
        public void MouseEvents_OnMouseMove(MouseButtonEnum button, ShiftStateEnum shiftKeys, Point modelPosition, Point2d viewPosition, View view)
        {
            m_parentCmd.OnMouseMove(button, shiftKeys, modelPosition, viewPosition, view);
        }

        //-----------------------------------------------------------------------------
        public void MouseEvents_OnMouseLeave(MouseButtonEnum button, ShiftStateEnum shiftKeys, View view)
        {
            m_parentCmd.OnMouseLeave(button, shiftKeys, view);
        }

        //-----------------------------------------------------------------------------
        //----- Implementation of Triad Events sink methods
        //-----------------------------------------------------------------------------

        //-----------------------------------------------------------------------------
        public void TriadEvents_OnActivate(NameValueMap context, out HandlingCodeEnum handlingCode)
        {
            m_parentCmd.OnActivate(context, out handlingCode);
        }

        //-----------------------------------------------------------------------------
        public void TriadEvents_OnEndMove(TriadSegmentEnum selectedTriadSegment, ShiftStateEnum shiftKeys, Matrix coordinateSystem, NameValueMap context, out HandlingCodeEnum handlingCode)
        {
            m_parentCmd.OnEndMove(selectedTriadSegment, shiftKeys, coordinateSystem, context, out handlingCode);
        }

        //----------------------------------------------------------------------------
        public void TriadEvents_OnMove(TriadSegmentEnum selectedTriadSegment, ShiftStateEnum shiftKeys, Matrix coordinateSystem, NameValueMap context, out HandlingCodeEnum handlingCode)
        {
            m_parentCmd.OnMove(selectedTriadSegment, shiftKeys, coordinateSystem, context, out handlingCode);
        }

        //-----------------------------------------------------------------------------
        public void TriadEvents_OnEndSequence(bool cancelled, Matrix coordinateSystem, NameValueMap context, out HandlingCodeEnum handlingCode)
        {
            m_parentCmd.OnEndSequence(cancelled, coordinateSystem, context, out handlingCode);
        }

        //-----------------------------------------------------------------------------
        public void TriadEvents_OnStartSequence(Matrix coordinateSystem, NameValueMap context, out HandlingCodeEnum handlingCode)
        {
            m_parentCmd.OnStartSequence(coordinateSystem, context, out handlingCode);
        }

        //-----------------------------------------------------------------------------
        public void TriadEvents_OnMoveTriadOnlyToggle(bool moveTriadOnly, EventTimingEnum beforeOrAfter, NameValueMap context, out HandlingCodeEnum handlingCode)
        {
            m_parentCmd.OnMoveTriadOnlyToggle(moveTriadOnly, beforeOrAfter, context, out handlingCode);
        }

        //-----------------------------------------------------------------------------
        public void TriadEvents_OnStartMove(TriadSegmentEnum selectedTriadSegment, ShiftStateEnum shiftKeys, Matrix coordinateSystem, NameValueMap context, out HandlingCodeEnum handlingCode)
        {
            m_parentCmd.OnStartMove(selectedTriadSegment, shiftKeys, coordinateSystem, context, out handlingCode);
        }

        //-----------------------------------------------------------------------------
        public void TriadEvents_OnTerminate(bool cancelled, NameValueMap context, out HandlingCodeEnum handlingCode)
        {
            m_parentCmd.OnTerminate(cancelled, context, out handlingCode);
        }

        //-----------------------------------------------------------------------------
        public void TriadEvents_OnSegmentSelectionChange(TriadSegmentEnum selectedTriadSegment, EventTimingEnum beforeOrAfter, NameValueMap context, out HandlingCodeEnum handlingCode)
        {
            m_parentCmd.OnSegmentSelectionChange(selectedTriadSegment, beforeOrAfter, context, out handlingCode);
        }
    }
}
