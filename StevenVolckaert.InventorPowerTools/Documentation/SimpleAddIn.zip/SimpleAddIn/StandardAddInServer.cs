using System;
using System.Drawing;
using System.Runtime.InteropServices;
using System.Windows.Forms;
using Inventor;

namespace SimpleAddIn
{
    /// <summary>
    /// This is the primary AddIn Server class that implements the ApplicationAddInServer interface
    /// that all Inventor AddIns are required to implement. The communication between Inventor and
    /// the AddIn is via the methods on this interface.
    /// </summary>
    [GuidAttribute("963308E2-D850-466D-A1C5-503A2E171552")]
    public class AddInServer : Inventor.ApplicationAddInServer
    {
        private Inventor.Application _inventorApplication;

        // buttons
        private AddSlotOptionButton m_addSlotOptionButton;
        private DrawSlotButton m_drawSlotButton;
        private ToggleSlotStateButton m_toggleSlotStateButton;

        // combo-boxes
        private ComboBoxDefinition _slotWidthComboBoxDefinition;
        private ComboBoxDefinition _slotHeightComboBoxDefinition;

        // user interface event
        private UserInterfaceEvents _userInterfaceEvents;

        // ribbon panel
        RibbonPanel _partSketchSlotRibbonPanel;

        // event handler delegates
        private Inventor.ComboBoxDefinitionSink_OnSelectEventHandler SlotWidthComboBox_OnSelectEventDelegate;
        private Inventor.ComboBoxDefinitionSink_OnSelectEventHandler SlotHeightComboBox_OnSelectEventDelegate;

        #region ApplicationAddInServer Members

        public void Activate(Inventor.ApplicationAddInSite addInSiteObject, bool firstTime)
        {
            try
            {
                //the Activate method is called by Inventor when it loads the addin
                //the AddInSiteObject provides access to the Inventor Application object
                //the FirstTime flag indicates if the addin is loaded for the first time

                //initialize AddIn members
                _inventorApplication = addInSiteObject.Application;
                Button.InventorApplication = _inventorApplication;

                //initialize event delegates
                _userInterfaceEvents = _inventorApplication.UserInterfaceManager.UserInterfaceEvents;
                _userInterfaceEvents.OnResetCommandBars += OnResetCommandBars;
                _userInterfaceEvents.OnResetEnvironments += OnResetEnvironments;
                _userInterfaceEvents.OnResetRibbonInterface += OnResetRibbonInterface;

                //load image icons for UI items
                Icon addSlotOptionIcon = new Icon(this.GetType(), "AddSlotOption.ico");
                Icon drawSlotIcon = new Icon(this.GetType(), "DrawSlot.ico");
                Icon toggleSlotStateIcon = new Icon(this.GetType(), "ToggleSlotState.ico");

                //retrieve the GUID for this class
                GuidAttribute addInCLSID;
                addInCLSID = (GuidAttribute)GuidAttribute.GetCustomAttribute(typeof(AddInServer), typeof(GuidAttribute));
                string addInCLSIDString;
                addInCLSIDString = "{" + addInCLSID.Value + "}";

                //create the comboboxes
                _slotWidthComboBoxDefinition = _inventorApplication.CommandManager.ControlDefinitions.AddComboBoxDefinition("Slot Width", "Autodesk:SimpleAddIn:SlotWidthCboBox", CommandTypesEnum.kShapeEditCmdType, 100, addInCLSIDString, "Slot width", "Slot width", Type.Missing, Type.Missing, ButtonDisplayEnum.kDisplayTextInLearningMode);
                _slotHeightComboBoxDefinition = _inventorApplication.CommandManager.ControlDefinitions.AddComboBoxDefinition("Slot Height", "Autodesk:SimpleAddIn:SlotHeightCboBox", CommandTypesEnum.kShapeEditCmdType, 100, addInCLSIDString, "Slot height", "Slot height", Type.Missing, Type.Missing, ButtonDisplayEnum.kDisplayTextInLearningMode);

                //add some initial items to the comboboxes
                _slotWidthComboBoxDefinition.AddItem("1 cm", 0);
                _slotWidthComboBoxDefinition.AddItem("2 cm", 0);
                _slotWidthComboBoxDefinition.AddItem("3 cm", 0);
                _slotWidthComboBoxDefinition.AddItem("4 cm", 0);
                _slotWidthComboBoxDefinition.AddItem("5 cm", 0);
                _slotWidthComboBoxDefinition.ListIndex = 1;
                _slotWidthComboBoxDefinition.ToolTipText = _slotWidthComboBoxDefinition.Text;
                _slotWidthComboBoxDefinition.DescriptionText = "Slot width: " + _slotWidthComboBoxDefinition.Text;

                SlotWidthComboBox_OnSelectEventDelegate = new ComboBoxDefinitionSink_OnSelectEventHandler(SlotWidthComboBox_OnSelect);
                _slotWidthComboBoxDefinition.OnSelect += SlotWidthComboBox_OnSelectEventDelegate;

                _slotHeightComboBoxDefinition.AddItem("1 cm", 0);
                _slotHeightComboBoxDefinition.AddItem("2 cm", 0);
                _slotHeightComboBoxDefinition.AddItem("3 cm", 0);
                _slotHeightComboBoxDefinition.AddItem("4 cm", 0);
                _slotHeightComboBoxDefinition.AddItem("5 cm", 0);
                _slotHeightComboBoxDefinition.ListIndex = 1;
                _slotHeightComboBoxDefinition.ToolTipText = _slotHeightComboBoxDefinition.Text;
                _slotHeightComboBoxDefinition.DescriptionText = "Slot height: " + _slotHeightComboBoxDefinition.Text;

                SlotHeightComboBox_OnSelectEventDelegate = new ComboBoxDefinitionSink_OnSelectEventHandler(SlotHeightComboBox_OnSelect);
                _slotHeightComboBoxDefinition.OnSelect += SlotHeightComboBox_OnSelectEventDelegate;

                //create buttons
                m_addSlotOptionButton = new AddSlotOptionButton(
                    "Add Slot width/height", "Autodesk:SimpleAddIn:AddSlotOptionCmdBtn", CommandTypesEnum.kShapeEditCmdType,
                    addInCLSIDString, "Adds option for slot width/height",
                    "Add slot option", addSlotOptionIcon, addSlotOptionIcon, ButtonDisplayEnum.kDisplayTextInLearningMode);

                m_drawSlotButton = new DrawSlotButton(
                    "Draw Slot", "Autodesk:SimpleAddIn:DrawSlotCmdBtn", CommandTypesEnum.kShapeEditCmdType,
                    addInCLSIDString, "Create slot sketch graphics",
                    "Draw Slot", drawSlotIcon, drawSlotIcon, ButtonDisplayEnum.kDisplayTextInLearningMode);

                m_toggleSlotStateButton = new ToggleSlotStateButton(
                    "Toggle Slot State", "Autodesk:SimpleAddIn:ToggleSlotStateCmdBtn", CommandTypesEnum.kShapeEditCmdType,
                    addInCLSIDString, "Enables/Disables state of slot command",
                    "Toggle Slot State", toggleSlotStateIcon, toggleSlotStateIcon, ButtonDisplayEnum.kDisplayTextInLearningMode);

                // Create the command category
                var slotCmdCategory = _inventorApplication.CommandManager.CommandCategories.Add("Slot", "Autodesk:SimpleAddIn:SlotCmdCat", addInCLSIDString);
                slotCmdCategory.Add(_slotWidthComboBoxDefinition);
                slotCmdCategory.Add(_slotHeightComboBoxDefinition);
                slotCmdCategory.Add(m_addSlotOptionButton.ButtonDefinition);
                slotCmdCategory.Add(m_drawSlotButton.ButtonDefinition);
                slotCmdCategory.Add(m_toggleSlotStateButton.ButtonDefinition);

                if (firstTime == true)
                {
                    // access user interface manager
                    var userInterfaceManager = _inventorApplication.UserInterfaceManager;

                    if (userInterfaceManager.InterfaceStyle == InterfaceStyleEnum.kClassicInterface)
                    {
                        //create the UI for classic interface

                        //create toolbar
                        CommandBar slotCommandBar;
                        slotCommandBar = userInterfaceManager.CommandBars.Add("Slot", "Autodesk:SimpleAddIn:SlotToolbar", CommandBarTypeEnum.kRegularCommandBar, addInCLSIDString);

                        //add comboboxes to toolbar
                        slotCommandBar.Controls.AddComboBox(_slotWidthComboBoxDefinition, 0);
                        slotCommandBar.Controls.AddComboBox(_slotHeightComboBoxDefinition, 0);

                        //add buttons to toolbar
                        slotCommandBar.Controls.AddButton(m_addSlotOptionButton.ButtonDefinition, 0);
                        slotCommandBar.Controls.AddButton(m_drawSlotButton.ButtonDefinition, 0);
                        slotCommandBar.Controls.AddButton(m_toggleSlotStateButton.ButtonDefinition, 0);

                        //Get the 2d sketch environment base object
                        Inventor.Environment partSketchEnvironment;
                        partSketchEnvironment = userInterfaceManager.Environments["PMxPartSketchEnvironment"];

                        //make this command bar accessible in the panel menu for the 2d sketch environment.
                        partSketchEnvironment.PanelBar.CommandBarList.Add(slotCommandBar);
                    }
                    else
                    {
                        var ribbonPanels = userInterfaceManager.Ribbons["Part"].RibbonTabs["id_TabSketch"].RibbonPanels;

                        _partSketchSlotRibbonPanel = ribbonPanels.Add("Slot", "Autodesk:SimpleAddIn:SlotRibbonPanel", "{DB59D9A7-EE4C-434A-BB5A-F93E8866E872}", "", false);

                        //add controls to the slot panel
                        var partSketchSlotRibbonPanelCtrls = _partSketchSlotRibbonPanel.CommandControls;

                        //add the combo boxes to the ribbon panel  
                        partSketchSlotRibbonPanelCtrls.AddComboBox(_slotWidthComboBoxDefinition, "", false);
                        partSketchSlotRibbonPanelCtrls.AddComboBox(_slotHeightComboBoxDefinition, "", false);

                        //add the buttons to the ribbon panel
                        partSketchSlotRibbonPanelCtrls.AddButton(m_drawSlotButton.ButtonDefinition, false, true, "", false);
                        partSketchSlotRibbonPanelCtrls.AddButton(m_addSlotOptionButton.ButtonDefinition, false, true, "", false);
                        partSketchSlotRibbonPanelCtrls.AddButton(m_toggleSlotStateButton.ButtonDefinition, false, true, "", false);
                    }
                }

                MessageBox.Show("To access the commands of the sample addin, activate a 2d sketch of a part \n document and select the \"AddInSlot\" toolbar within the panel menu");
            }
            catch (Exception e)
            {
                MessageBox.Show(e.ToString());
            }
        }

        public void Deactivate()
        {
            try
            {
                _userInterfaceEvents.OnResetCommandBars -= OnResetCommandBars;
                _userInterfaceEvents.OnResetEnvironments -= OnResetEnvironments;
                _userInterfaceEvents = null;

                if (_partSketchSlotRibbonPanel != null)
                    _partSketchSlotRibbonPanel.Delete();

                Marshal.ReleaseComObject(_inventorApplication);
                _inventorApplication = null;

                GC.WaitForPendingFinalizers();
                GC.Collect();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        public void ExecuteCommand(int CommandID)
        {
            //this method was used to notify when an AddIn command was executed
            //the CommandID parameter identifies the command that was executed

            //Note:this method is now obsolete, you should use the new
            //ControlDefinition objects to implement commands, they have
            //their own event sinks to notify when the command is executed
        }

        public object Automation
        {
            //if you want to return an interface to another client of this addin,
            //implement that interface in a class and return that class object 
            //through this property

            get
            {
                return null;
            }
        }

        private void OnResetCommandBars(ObjectsEnumerator commandBars, NameValueMap context)
        {
            try
            {
                CommandBar commandBar;
                for (int commandBarCt = 1; commandBarCt <= commandBars.Count; commandBarCt++)
                {
                    commandBar = (Inventor.CommandBar)commandBars[commandBarCt];
                    if (commandBar.InternalName == "Autodesk:SimpleAddIn:SlotToolbar")
                    {
                        //add comboboxes to toolbar
                        commandBar.Controls.AddComboBox(_slotWidthComboBoxDefinition, 0);
                        commandBar.Controls.AddComboBox(_slotHeightComboBoxDefinition, 0);

                        //add buttons to toolbar
                        commandBar.Controls.AddButton(m_addSlotOptionButton.ButtonDefinition, 0);
                        commandBar.Controls.AddButton(m_drawSlotButton.ButtonDefinition, 0);
                        commandBar.Controls.AddButton(m_toggleSlotStateButton.ButtonDefinition, 0);

                        return;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void OnResetEnvironments(ObjectsEnumerator environments, NameValueMap context)
        {
            try
            {
                Inventor.Environment environment;
                for (int environmentCt = 1; environmentCt <= environments.Count; environmentCt++)
                {
                    environment = (Inventor.Environment)environments[environmentCt];
                    if (environment.InternalName == "PMxPartSketchEnvironment")
                    {
                        //make this command bar accessible in the panel menu for the 2d sketch environment.
                        environment.PanelBar.CommandBarList.Add(_inventorApplication.UserInterfaceManager.CommandBars["Autodesk:SimpleAddIn:SlotToolbar"]);

                        return;
                    }
                }
            }
            catch (Exception e)
            {
                MessageBox.Show(e.ToString());
            }
        }

        private void OnResetRibbonInterface(NameValueMap context)
        {
            try
            {
                var userInterfaceManager = _inventorApplication.UserInterfaceManager;

                // get the ribbon associated with part document
                var ribbons = userInterfaceManager.Ribbons;
                var partRibbon = ribbons["Part"];

                // create a new panel in the tab
                _partSketchSlotRibbonPanel =
                    partRibbon.RibbonTabs["id_TabSketch"].RibbonPanels.Add(
                        DisplayName: "Slot",
                        InternalName: "Autodesk:SimpleAddIn:SlotRibbonPanel",
                        ClientId: "{DB59D9A7-EE4C-434A-BB5A-F93E8866E872}",
                        TargetPanelInternalName: "",
                        InsertBeforeTargetPanel: false);

                // add the combo boxes to the new panel  
                _partSketchSlotRibbonPanel.CommandControls.AddComboBox(_slotWidthComboBoxDefinition, "", false);
                _partSketchSlotRibbonPanel.CommandControls.AddComboBox(_slotHeightComboBoxDefinition, "", false);

                // add the buttons to the new panel
                _partSketchSlotRibbonPanel.CommandControls.AddButton(m_drawSlotButton.ButtonDefinition, false, true, "", false);
                _partSketchSlotRibbonPanel.CommandControls.AddButton(m_addSlotOptionButton.ButtonDefinition, false, true, "", false);
                _partSketchSlotRibbonPanel.CommandControls.AddButton(m_toggleSlotStateButton.ButtonDefinition, false, true, "", false);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void SlotWidthComboBox_OnSelect(NameValueMap context)
        {
            _slotWidthComboBoxDefinition.ToolTipText = _slotWidthComboBoxDefinition.Text;
            _slotWidthComboBoxDefinition.DescriptionText = "Slot width: " + _slotWidthComboBoxDefinition.Text;
        }

        private void SlotHeightComboBox_OnSelect(NameValueMap context)
        {
            _slotHeightComboBoxDefinition.ToolTipText = _slotHeightComboBoxDefinition.Text;
            _slotHeightComboBoxDefinition.DescriptionText = "Slot height: " + _slotHeightComboBoxDefinition.Text;
        }

        #endregion
    }
}
